$(document)
  .ready(function() {

    $('.filter.menu .item')
      .tab()
    ;

  })
;